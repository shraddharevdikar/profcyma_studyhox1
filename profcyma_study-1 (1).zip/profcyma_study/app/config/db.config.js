module.exports = {
  HOST: "3.7.252.202",
  PORT: 27017,
  DB: "scholarity",
  USERNAME: 'atharv',
  PASSWORD: 'atharv123'
};