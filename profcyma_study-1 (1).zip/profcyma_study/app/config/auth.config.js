module.exports = {
  secret: "profcyma-secret-key"
};
